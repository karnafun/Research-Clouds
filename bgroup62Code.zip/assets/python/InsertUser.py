import sys
import script
print(sys.argv[1])
# print('hello')
# print (script.TestFunction())
# res = script.GetNames()
print(script.ExctractUserInfo(sys.argv[1]))